
// إعدادات اللعبة
const launchButton = document.getElementById('launchButton');
const gameArea = document.getElementById('gameArea');
let missileTimeout;

// إطلاق الصواريخ
launchButton.addEventListener('click', () => {
    launchMissile();
});

// دالة لإطلاق الصاروخ
function launchMissile() {
    const missile = document.createElement('div');
    missile.classList.add('missile');
    gameArea.appendChild(missile);

    missile.style.left = '50px';
    missile.style.bottom = '50px';

    let missilePos = 50;
    let interval = setInterval(() => {
        missilePos += 5;
        missile.style.bottom = `${missilePos}px`;

        if (missilePos > gameArea.offsetHeight - 100) {
            clearInterval(interval);
            missile.style.display = 'none';
            explode(missile);
        }
    }, 20);
}

// دالة لتفجير الصاروخ عند الوصول
function explode(missile) {
    const explosion = document.createElement('div');
    explosion.classList.add('explosion');
    explosion.style.left = `${missile.offsetLeft - 50}px`;
    explosion.style.bottom = `${missile.offsetTop}px`;
    gameArea.appendChild(explosion);

    setTimeout(() => {
        explosion.style.display = 'none';
    }, 500);
}

const style = document.createElement('style');
style.innerHTML = `
    .missile {
        width: 10px;
        height: 30px;
        background-color: yellow;
        position: absolute;
        animation: missileMove 2s linear infinite;
    }

    .explosion {
        width: 50px;
        height: 50px;
        background-color: orange;
        border-radius: 50%;
        position: absolute;
        animation: explosionEffect 0.5s forwards;
    }

    @keyframes missileMove {
        0% {
            transform: translateY(0);
        }
        100% {
            transform: translateY(-500px);
        }
    }

    @keyframes explosionEffect {
        0% {
            transform: scale(0);
            opacity: 1;
        }
        100% {
            transform: scale(3);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
